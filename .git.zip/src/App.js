import logo from './images/Picture1.png';
import logo2 from './images/Picture2.png';
import logo3 from './images/Picture3.png';
import logo4 from './images/logo.png';
import logo5 from './images/Picture4.png';
import logo6 from './images/Picture5.png';

import './App.css';

function App() {
  return (
    <>
      <div className="App">
        <div className="navbar">
          <nav className="bg-white dark:bg-gray-900 fixed w-full z-20 top-0 left-0  border-gray-200 dark:border-gray-600">
            <div className="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
              <div href="" className="flex items-center">
                <img
                  src={logo4}
                  className="h-8 text-black mr-3"
                  alt="Flowbite Logo"
                />
                <span className="self-center text-3xl font-semibold whitespace-nowrap dark:text-white">
                  ChainLabo
                </span>
              </div>
              <div className="flex md:order-2">
                <button
                  type="button"
                  className="text-white bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-xl px-4 py-2 text-center mr-3 md:mr-0 dark:bg-blue-600 dark:hover:bg-orange-500 dark:focus:ring-blue-800"
                >
                  Book a Call
                </button>
              </div>
              <div
                className="items-center justify-between hidden w-full md:flex md:w-auto md:order-1"
                id="navbar-sticky"
              >
                <ul className="flex  flex-col p-4 md:p-0 mt-4 font-medium border border-gray-100 rounded-lg bg-gray-50 md:flex-row md:space-x-8 md:mt-0 md:border-0 md:bg-white dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
                  <div
                    id="sticky-banner"
                    className="flex justify-between p-4  dark:bg-gray-700 dark:border-gray-600"
                  >
                    <div className="flex items-center mx-auto">
                      <p className="flex items-center text-sm font-normal text-gray-500 dark:text-gray-400">
                        <span className="inline-flex p-1 mr-3 bg-gray-200 rounded-full dark:bg-gray-600 w-8 h-8 items-center justify-center">
                          <svg
                            className="w-6 h-6 text-gray-500 dark:text-gray-400"
                            aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg"
                            fill="currentColor"
                            viewBox="0 0 18 19"
                          >
                            <path d="M15 1.943v12.114a1 1 0 0 1-1.581.814L8 11V5l5.419-3.871A1 1 0 0 1 15 1.943ZM7 4H2a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2v5a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2V4ZM4 17v-5h1v5H4ZM16 5.183v5.634a2.984 2.984 0 0 0 0-5.634Z" />
                          </svg>
                        </span>
                        <span className='text-xl dark:text-white text-black font-bold'>
                          Avail 40% Service Discount{" "}
                        </span>
                      </p>
                    </div>
                  </div>
                </ul>
              </div>
            </div>
          </nav>
        </div>



        <div className="body1 mt-[20vh] p-10">
          <section className="bg-white dark:bg-gray-900 flex">
            <div className="md:py-8 mx-auto md:px-4  w-full md:w-[50vw] text-center lg:py-16">
              <h1 className="mb-4 text-left text-4xl font-extrabold tracking-tight leading-none text-orange-400 md:text-4xl lg:text-6xl dark:text-orange-500">
                Solo Ethereum Staking
              </h1>
              <p className="mb-8 text-left text-lg font-normal text-gray-500 lg:text-xl  dark:text-gray-400">
                At chain Labo Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolore qui minus ea veniam quibusdam repellat!
              </p>
              <div className="flex flex-col space-y-4 sm:flex-row  sm:space-y-0 sm:space-x-4">
                <a
                  href="#"
                  className="inline-flex justify-center items-center py-3 px-5 text-base font-medium text-center text-white rounded-lg bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:ring-blue-300 dark:focus:ring-blue-900"
                >
                  Book a Call
                  <svg
                    className="w-3.5 h-3.5 ml-2"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 14 10"
                  >
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M1 5h12m0 0L9 1m4 4L9 9"
                    />
                  </svg>
                </a>
              </div>
            </div>
            <div className="py-8 md:flex mx-auto px-4 hidden md:w-[50vw] text-center lg:py-16">
              <img src={logo} />
            </div>
          </section>
        </div>





        <div className="body2 p-10">
          <section className="bg-white dark:bg-gray-900 flex">
            <div className="md:py-8 order-2 mx-auto md:px-4  w-full md:w-[50vw] text-center lg:py-16">
              <h1 className="mb-4 md:text-right text-left text-4xl font-extrabold tracking-tight leading-none text-gray-900 md:text-4xl lg:text-6xl dark:text-white">
                Exclusive Early Adopter Benefits
              </h1>
              <p className="mb-8 md:text-right text-left text-lg font-normal text-gray-500 lg:text-xl  dark:text-gray-400">
                At chain Labo Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolore qui minus ea veniam quibusdam repellat!
              </p>
              <div className="flex flex-col justify-end space-y-4 md:flex-row  sm:space-y-0 sm:space-x-4">
                <a
                  href="#"
                  className="inline-flex  justify-center items-center py-3 px-5 text-base font-medium text-center text-white rounded-lg bg-orange-500 hover:bg-orange-600 focus:ring-4 focus:ring-blue-300 dark:focus:ring-blue-900"
                >
                  Book a Call
                  <svg
                    className="w-3.5 h-3.5 ml-2"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 14 10"
                  >
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M1 5h12m0 0L9 1m4 4L9 9"
                    />
                  </svg>
                </a>
              </div>
            </div>
            <div className="py-8 order-1 md:flex mx-auto px-4 hidden md:w-[50vw] justify-start  lg:py-16">
              <img className='justify-start flex' src={logo2} />
            </div>
          </section>
        </div>




        <div className="body2 p-10">
          <section className="bg-white dark:bg-gray-900 flex">
            <div className="md:py-8 order-1 mx-auto md:px-4  w-full md:w-[50vw] text-center lg:py-16">
              <h1 className="mb-4  text-left text-4xl font-extrabold tracking-tight leading-none text-gray-900 md:text-4xl lg:text-6xl dark:text-white">
                Who we Are ?
              </h1>
              <p className="mb-8 text-left text-lg font-normal text-gray-500 lg:text-xl  dark:text-gray-400">
                We are a Swiss-based company
                committed to helping you in your
                staking investment
              </p>
              <div className="flex flex-col space-y-4 md:flex-row  sm:space-y-0 sm:space-x-4">
                <div className="dark:text-white text-left text-xl">
                  <span className='text-orange-500 font-bold'>Your keys, your ETH </span>
                  : This is the simple vision of ChainLabo. We develop a set of products and services
                  that would enable private investors and family financial advisors to easily and securely manage cryptocurrencies
                </div>
              </div>
            </div>
            <div className="py-8 order-2 md:flex mx-auto px-4 hidden md:w-[50vw] justify-start  lg:py-16">
              <img className='flex-shrink-0 justify-start flex' src={logo3} />
            </div>
          </section>
        </div>




        <>
          {/* component */}
          <div className="flex items-center justify-center p-10">
            {/* Author: FormBold Team */}
            {/* Learn More: https://formbold.com */}
            <div className="mx-auto w-full max-w-[550px]">
              <h1 className="mb-20 text-center text-3xl font-bold tracking-tight leading-none text-gray-900 md:text-2xl lg:text-4xl dark:text-white">
                Contact Us
              </h1>
              <form action="https://formbold.com/s/FORM_ID" method="POST">
                <div className="flex mb-10 flex-row justify-between">
                  <div className="mb-5">
                    <input
                      type="text"
                      name="name"
                      id="name"
                      placeholder="Full Name"
                      className="w-full rounded-md border border-[#e0e0e0] bg-white py-3 px-6 text-base font-medium text-[#6B7280] outline-none focus:border-[#6A64F1] focus:shadow-md"
                    />
                  </div>
                  <div className="mb-5">
                    <input
                      type="email"
                      name="email"
                      id="email"
                      placeholder="example@domain.com"
                      className="w-full rounded-md border border-[#e0e0e0] bg-white py-3 px-6 text-base font-medium text-[#6B7280] outline-none focus:border-[#6A64F1] focus:shadow-md"
                    />
                  </div>
                </div>
                <div className="mb-5">
                  <textarea
                    rows={4}
                    name="message"
                    id="message"
                    placeholder="Type your message"
                    className="w-full resize-none rounded-md border border-[#e0e0e0] bg-white py-3 px-6 text-base font-medium text-[#6B7280] outline-none focus:border-[#6A64F1] focus:shadow-md"
                    defaultValue={""}
                  />
                </div>
                <div>
                  <button className="hover:shadow-form rounded-md bg-orange-500 py-3 px-8 text-base font-semibold text-white outline-none">
                    Submit
                  </button>
                </div>
              </form>
            </div>
          </div>

          <div className="mt-9">
            <>
              <footer className="relative bg-blueGray-200 pt-8 pb-6">
                <div className="container mx-auto px-4">
                  <div className="flex justify-between flex-row text-left lg:text-left">
                    <div className="w-[50%] px-4">
                      <div href="" className="flex items-center">
                        <img
                          src={logo4}
                          className="h-8 text-black mr-3"
                          alt="Flowbite Logo"
                        />
                        <span className="self-center text-3xl font-semibold whitespace-nowrap dark:text-white">
                          ChainLabo
                        </span>
                      </div>
                      <h5 className="text-lg mt-8 mb-2 text-blueGray-600">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. At consequuntur et reprehenderit similique temporibus inventore adipisci nostrum quam amet molestias id ut repellendus maxime distinctio fugiat molestiae omnis non aperiam necessitatibus itaque ex deserunt impedit, sequi veritatis? Impedit vitae obcaecati suscipit! Nulla laborum quo dolores non dicta, sint doloremque amet hic, ad minima sed repellat esse eum assumenda magnam natus maxime velit iusto!
                      </h5>
                    </div>
                    <div className="px-4">
                      <div className="px-4 ml-auto">
                        <span className="block  uppercase text-blueGray-500 text-2xl font-semibold mb-10 text-orange-500">
                          Our Social
                        </span>
                        <div className="flex flex-row space-x-10">
                          <div className="">
                            <img src={logo5} alt="" className="w-14" />
                          </div>
                          <div className="">
                            <img src={logo6} alt="" className="w-14" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </footer>
            </>

          </div>

          <div className="fotterpart2">
            <footer classname="bg-white rounded-lg shadow m-4 dark:bg-gray-800">
              <div className="w-full mx-auto max-w-screen-xl p-4 md:flex md:items-center md:justify-between">
                <span className="text-sm text-gray-500 sm:text-center dark:text-gray-400">
                  © 2023{" "}
                  <a href="" className="hover:underline">
                    ChainLabo™
                  </a>
                  . All Rights Reserved.
                </span>
                <ul className="flex flex-wrap items-center mt-3 text-sm font-medium text-gray-500 dark:text-gray-400 sm:mt-0">
                  <li>
                    <a href="#" className="mr-4 hover:underline md:mr-6 ">
                      About
                    </a>
                  </li>
                  <li>
                    <a href="#" className="mr-4 hover:underline md:mr-6">
                      Privacy Policy
                    </a>
                  </li>
                  <li>
                    <a href="#" className="mr-4 hover:underline md:mr-6">
                      Licensing
                    </a>
                  </li>
                  <li>
                    <a href="#" className="hover:underline">
                      Contact
                    </a>
                  </li>
                </ul>
              </div>
            </footer>
          </div>


        </>
      </div>
    </>
  )
}

export default App;
